create view product_view as
select `onlinemagazine`.`products`.`id` AS `id`
from `onlinemagazine`.`products`;

